# Canvas Agent

A deterministic Python guardrail for the autonomous HW3 Canvas forum agent. The code is built in this repository; deploy the directory as `~/hw3-agent` so paths in `RUNTIME.md` match.

## Requirements

- macOS or Linux
- `uv`
- Python 3.11+
- A Canvas token placed by the human, never by Hermes

## Install

```sh
cd ~/hw3-agent
uv sync --extra test
chmod 755 bin/canvas_tool scripts/collect_evidence.sh scripts/*.py
mkdir -p state/drafts logs
chmod 700 state state/drafts logs
```

The human creates the credential file outside the repository:

```sh
mkdir -p ~/.config/hw3-agent
chmod 700 ~/.config/hw3-agent
# Add exactly CANVAS_TOKEN=<new token> to ~/.config/hw3-agent/env
chmod 600 ~/.config/hw3-agent/env
```

Do not paste the token into a Hermes conversation. `canvas_tool` is the only component that reads it.

## Test and dry run

```sh
uv run --extra test pytest -q
bin/canvas_tool status
```

`status` is read-only. Before the credential exists it safely returns one JSON error object.

## Commands

```text
canvas_tool begin
canvas_tool new --run ID
canvas_tool thread --run ID --entry EID
canvas_tool post --run ID (--reply-to EID | --new-thread) --message-file PATH
canvas_tool skip --run ID --reason TEXT
canvas_tool end --run ID --outcome ok|error
canvas_tool status
```

Draft files must be regular UTF-8 files directly inside `state/drafts`; symlinks and paths elsewhere are refused. Every invocation writes one JSON object to stdout and one redacted JSONL audit record.

## Deployment

1. Review `ARCHITECTURE.md` and `RUNTIME.md`.
2. Keep the Hermes gateway alive with launchd.
3. Create a dedicated Hermes profile whose cron toolset disables web, browser, code execution, delegation, memory, and other unrelated tools; retain terminal access for the wrapper and file access for drafts.
4. Add the recurring cron job with `*/30 * * * *` and the exact prompt documented in `ARCHITECTURE.md`.
5. Observe two unattended runs in `logs/agent.jsonl` before considering autonomy verified.

These machine-level steps are intentionally not automatic. They require the human's credential, gateway choice, messaging destination, and approval.

## Evidence

```sh
scripts/collect_evidence.sh
```

The collector first runs a repository secret scan, then writes redacted run and verified-link evidence to `evidence/scheduled_runs.md`. Complete the live lost-ack exercise in `evidence/failure_recovery.md` after the course forum is available.
